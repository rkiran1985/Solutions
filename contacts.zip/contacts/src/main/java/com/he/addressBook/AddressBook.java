package com.he.addressBook;

import java.util.List;

public class AddressBook {

	
    public AddressBook() {
        //TODO
    }

    public void addContact(Contact contact) {
     
    	if(null!=contact && null!=contact.getName()){
    	  AddressBook address = new AddressBook();
    	  List<Contact> contactList = address.searchByName(contact.getName());
    	  for(Contact contactListData : contactList)
    	  {
    		  if(contactListData.getName()==contact.getName())
    		  {
    			  throw new RuntimeException("Record Already Exist for Name "+contact.getName());
    		  }
    		 
    	  }
    	  Trie t = new Trie();
		  t.insert(contact.getName(),contact);
      }
    }

	
	  public void deleteContact(String name){
		
		try {
			Contact contact = new Contact(name ,null);
			  AddressBook address = new AddressBook();
			  List<Contact> contactList = address.searchByName(contact.getName());
			  for(Contact contactListData : contactList)
	    	  {
	    		  if(contactListData.getName()==contact.getName())
	    		  {
	    			  throw new RuntimeException("Record deleted Exist for Name "+contact.getName());
	    		  }
	    		 
	    	  }
			 Trie t = new Trie();
			 t.delete(name, contact);
		} catch (Exception e) 
		{
			e.printStackTrace();
		} 
		  
	  }
	  
	  
	  public void updateContact(String name, Contact contact) { 
		  AddressBook address = new AddressBook();
    	  List<Contact> contactList = address.searchByName(contact.getName());
    	  for(Contact contactListData : contactList)
    	  {
    		  if(contactListData.getName()==contact.getName())
    		  {
    			  throw new RuntimeException("Record Already Exist for Name"+contact.getName());
    		  }
    		}
    	  
    	  throw new RuntimeException("Record Not Exist for Name"+contact.getName());
		}
	  
	  
	  
	  
	  
	  public List<Contact> searchByName(String name) { 
		  return null; 
	  }
	  
	  public List<Contact> searchByOrganisation(String organisation) {
		  
	  return null; 
	  }
	 

}